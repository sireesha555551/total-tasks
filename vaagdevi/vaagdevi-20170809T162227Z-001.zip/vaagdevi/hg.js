function  myFun(){
document.getElementById("ab").innerHTML="halj";
}